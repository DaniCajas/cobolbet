package com.example.vidalbetlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;

public class RegisterController {

    @FXML private TextField nomField;
    @FXML private TextField cognomsField;
    @FXML private TextField dataField;
    @FXML private TextField dniField;
    @FXML private TextField cpField;
    @FXML private TextField paisField;

    @FXML
    public void handleRegister(ActionEvent event) {
        // Aquí recogerás los datos en el futuro para la Base de Datos
        System.out.println("Registrando nuevo usuario: " + nomField.getText());

        // Mostrar mensaje de éxito
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Registre completat");
        alert.setHeaderText(null);
        alert.setContentText("L'usuari s'ha registrat correctament!");
        alert.showAndWait();

        // Cerrar la ventana de registro automáticamente después de aceptar
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}