package com.example.vidalbetlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField userField;
    @FXML private PasswordField passField;

    @FXML
    public void handleLogin(ActionEvent event) {
        String user = userField.getText();
        System.out.println("Intentant iniciar sessió amb: " + user);
        // Más adelante aquí pondremos la comprobación de la contraseña en la base de datos
    }

    @FXML
    public void openRegister(ActionEvent event) {
        try {
            System.out.println("Obrint la finestra de registre...");

            // Carga el diseño del registro
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/vidalbetlogin/RegisterApp.fxml"));
            Parent root = fxmlLoader.load();

            // Crea y muestra la nueva ventana
            Stage stage = new Stage();
            stage.setTitle("VidalBet - Registre de nou usuari");
            stage.setScene(new Scene(root, 450, 700));
            stage.setResizable(false);
            stage.show();

        } catch (Exception e) {
            System.out.println("Error al obrir la finestra de registre:");
            e.printStackTrace(); // Esto nos chivará en la consola si hay algún error
        }
    }
}