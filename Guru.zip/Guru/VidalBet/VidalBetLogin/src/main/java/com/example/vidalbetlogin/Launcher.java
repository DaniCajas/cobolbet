package com.example.vidalbetlogin;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        // Aquí le decimos que arranque MainApp en lugar de HelloApplication
        Application.launch(MainApp.class, args);
    }
}