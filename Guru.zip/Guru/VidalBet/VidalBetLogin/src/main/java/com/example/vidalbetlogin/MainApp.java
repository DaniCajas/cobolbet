package com.example.vidalbetlogin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Busca el fitxer LoginApp.fxml que hem creat a la carpeta resources
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("LoginApp.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 400, 550);

        stage.setTitle("VidalBet - Inici de Sessió");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}