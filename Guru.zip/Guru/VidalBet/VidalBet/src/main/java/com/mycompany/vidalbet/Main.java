package com.mycompany.vidalbet;

import config.Conexion;
import dao.ApuestaDAO;
import java.io.*;
import java.sql.Connection;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ApuestaDAO dao = new ApuestaDAO();
        System.out.println("=== 🎰 VIDALBET: MODO COBOL ENGINE 🎰 ===");

        Connection cn = Conexion.getConexion();

        if (cn != null) {
            int idPaco = 1;
            double importe = 10.0;
            double cuota = 2.0;
            double saldoActual = dao.obtenerSaldoUsuario(idPaco);

            // 1. CREAR EL ARCHIVO PARA COBOL (APUESTA.DAT)
            // Formato: Saldo(00100.00) Importe(00010.00) Cuota(02.00)
            try (PrintWriter writer = new PrintWriter(new FileWriter("APUESTA.DAT"))) {
                writer.printf("%08.2f %08.2f %05.2f", saldoActual, importe, cuota);
                System.out.println("✅ Datos enviados a COBOL (APUESTA.DAT)");
            } catch (IOException e) {
                System.out.println("❌ Error al crear archivo para COBOL: " + e.getMessage());
            }

            // 2. EJECUTAR EL MOTOR COBOL
            try {
                System.out.println("⏳ Ejecutando motor de cálculo COBOL...");
                // Este comando compila y ejecuta el programa MOTOR.CBL
                // Executem directament l'executable que en Dani ja ha compilat
                Process p = Runtime.getRuntime().exec("./MOTOR.exe");                p.waitFor(); // Esperamos a que COBOL termine
            } catch (Exception e) {
                System.out.println("❌ Error al ejecutar COBOL: " + e.getMessage());
            }

            // 3. LEER EL RESULTADO DE COBOL (RESULTADO.DAT)
            try (Scanner reader = new Scanner(new File("RESULTADO.DAT"))) {
                if (reader.hasNext()) {
                    String resultadoCobol = reader.next(); // "GANADA" o "PERDIDA"
                    double nuevoSaldo = reader.nextDouble();

                    System.out.println("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                    System.out.println("  🏆 COBOL DICE: " + resultadoCobol.toUpperCase());
                    System.out.println("  💰 NUEVO SALDO CALCULADO POR COBOL: " + nuevoSaldo + "€");
                    System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

                    // 4. ACTUALIZAR BASE DE DATOS CON LO QUE DIJO COBOL
                    // Primero guardamos la apuesta (sin el trigger de resta, la guardamos directamente)
                    int idApuesta = dao.guardarApuestaYObtenerId(idPaco, importe, cuota, importe * cuota);
                    dao.actualizarEstadoApuesta(idApuesta, resultadoCobol.toLowerCase());
                    
                    // Actualizamos el saldo manualmente porque ya no hay Triggers
                    dao.recargarSaldo(idPaco, nuevoSaldo - saldoActual); 
                }
            } catch (FileNotFoundException e) {
                System.out.println("❌ COBOL no generó el archivo de resultado.");
            }

        } else {
            System.out.println("❌ Error: No hay conexión con MySQL.");
        }
        System.out.println("\n=== SIMULACIÓN FINALIZADA ===");
    }
}